"""Array-based document processing."""
