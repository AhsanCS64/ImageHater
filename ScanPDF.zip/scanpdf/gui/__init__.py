"""Tkinter desktop interface."""
